from setuptools import setup

setup(
    name='imet',
    packages=['imet'],
)
