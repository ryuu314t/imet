iMet Collection 2019 - FGVC6
============================

This is PyTorch baseline for https://www.kaggle.com/c/imet-2019-fgvc6/

License is MIT.
